import mysql.connector
import pandas as pd
from flask import Flask, jsonify, render_template, request, flash, redirect, url_for
import os
from datetime import datetime
from rdkit import Chem
import random
import string
from werkzeug.utils import secure_filename 

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['ALLOWED_EXTENSIONS'] = {'csv'}
app.config['SECRET_KEY'] = 'secret_key'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host="mysql-webdev.missouri.edu",
            port=3306,
            user="username", #ask Alina at arbcn@umsystem.edu to give you your username and password information
            password="password",
            database="mu_sar"
        )
        if connection.is_connected():
            print("Connected to the database successfully!")
        return connection
    except mysql.connector.Error as err:
        print(f"Database Connection Error: {err}")
        return None

def get_assay_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM assay")
        assay_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return assay_data
    except mysql.connector.Error as err:
        print(f"Error fetching assay data: {err}")
        return []
    
def get_chemist_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM chemist")
        chemist_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return chemist_data
    except mysql.connector.Error as err:
        print(f"Error fetching chemist data: {err}")
        return []
    
def get_counterion_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM counterion")
        counterion_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return counterion_data
    except mysql.connector.Error as err:
        print(f"Error fetching counterion data: {err}")
        return []
    
def get_project_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM project")
        project_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return project_data
    except mysql.connector.Error as err:
        print(f"Error fetching project data: {err}")
        return []

def get_result_type_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM result_type")
        result_type_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return result_type_data
    except mysql.connector.Error as err:
        print(f"Error fetching result type data: {err}")
        return []
    
def get_source_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM source")
        source_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return source_data
    except mysql.connector.Error as err:
        print(f"Error fetching source data: {err}")
        return []
    
def get_storage_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM storage")
        storage_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return storage_data
    except mysql.connector.Error as err:
        print(f"Error fetching storage data: {err}")
        return []
    
def get_target_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM target")
        target_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return target_data
    except mysql.connector.Error as err:
        print(f"Error fetching target data: {err}")
        return []
    
def get_lot_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM lot")
        lot_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return lot_data
    except mysql.connector.Error as err:
        print(f"Error fetching lot data: {err}")
        return []

def get_sample_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM sample")
        sample_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return sample_data
    except mysql.connector.Error as err:
        print(f"Error fetching sample data: {err}")
        return []
    
def get_activity_data():
    try:
        db_connection = get_db_connection()
        cursor = db_connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM activity")
        activity_data = cursor.fetchall()
        cursor.close()
        db_connection.close()
        return activity_data
    except mysql.connector.Error as err:
        print(f"Error fetching activity data: {err}")
        return []

    
    
#Open home page at the start up
@app.route('/')
def home():
    return render_template('index.html')


#Add new values
from flask import flash, redirect, url_for

@app.route('/add_assay', methods=['GET', 'POST'])
def add_assay():
    if request.method == 'POST':
        assay_name = request.form.get('assay_name')
        assay_lab = request.form.get('assay_lab')
        target_id = request.form.get('target_id')

        if not all([assay_name, assay_lab, target_id]):
            flash('All fields are required!', 'danger')
            return redirect(url_for('add_assay'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all existing assay_id values
            cursor.execute("SELECT assay_id FROM assay ORDER BY assay_id ASC")
            existing_ids = cursor.fetchall()

            # Find the smallest missing assay_id
            next_assay_id = 1
            for assay_id in existing_ids:
                if assay_id[0] != next_assay_id:
                    break
                next_assay_id += 1

            # Insert the new assay with the calculated assay_id
            query = """
                INSERT INTO assay (assay_id, assay_name, assay_lab, target_id)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (next_assay_id, assay_name, assay_lab, target_id))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Assay '{assay_name}' added successfully with ID {next_assay_id}.", "success")
            return redirect(url_for('add_assay'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_assay'))  # Redirect after error

    # Show all data from the assay table
    assay_data = get_assay_data()
    target_data = get_target_data()

    return render_template('add_assay.html', assay_data=assay_data, target_data=target_data)

@app.route('/add_chemist', methods=['GET', 'POST'])
def add_chemist():
    if request.method == 'POST':
        chemist_name = request.form.get('chemist_name')
        chemist_description = request.form.get('chemist_description')

        if not all([chemist_name, chemist_description]):
            flash('All fields are required!', 'danger')
            return redirect(url_for('add_chemist'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get the maximum existing chemist_id
            cursor.execute("SELECT MAX(chemist_id) FROM chemist")
            max_id = cursor.fetchone()[0]
            next_chemist_id = (max_id or 0) + 1  # Increment max_id or start at 1 if the table is empty

            # Insert the new chemist with the calculated chemist_id
            query = """
                INSERT INTO chemist (chemist_id, chemist_name, chemist_description)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (next_chemist_id, chemist_name, chemist_description))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Chemist '{chemist_name}' added successfully with ID {next_chemist_id}.", "success")
            return redirect(url_for('add_chemist'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_chemist'))  # Redirect after error

    # Show all data from the chemist table
    chemist_data = get_chemist_data()

    return render_template('add_chemist.html', chemist_data=chemist_data)


@app.route('/add_counterion', methods=['GET', 'POST'])
def add_counterion():
    if request.method == 'POST':
        ci_smiles = request.form.get('ci_smiles')

        if not ci_smiles:
            flash('Counterion Smiles are required!', 'danger')
            return redirect(url_for('add_counterion'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all the existing ci_code values
            cursor.execute("SELECT ci_code FROM counterion ORDER BY ci_code ASC")
            existing_codes = cursor.fetchall()

            # Find the smallest missing ci_code
            next_ci_code = 1
            for code in existing_codes:
                if code[0] != next_ci_code:
                    break
                next_ci_code += 1

            # Insert the new counterion with the calculated ci_code
            insert_query = """
                INSERT INTO counterion (ci_code, ci_smiles)
                VALUES (%s, %s)
            """
            cursor.execute(insert_query, (next_ci_code, ci_smiles))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Counterion with Smiles '{ci_smiles}' added successfully with code {next_ci_code}.", "success")
            return redirect(url_for('add_counterion'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_counterion'))  # Redirect after error

    # Show all data from the counterion table
    counterion_data = get_counterion_data()

    return render_template('add_counterion.html', counterion_data=counterion_data)

@app.route('/add_project', methods=['GET', 'POST'])
def add_project():
    if request.method == 'POST':
        project_name = request.form.get('project_name')
        project_description = request.form.get('project_description')

        if not all([project_name, project_description]):
            flash('All fields are required!', 'danger')
            return redirect(url_for('add_project'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all existing project_id values
            cursor.execute("SELECT project_id FROM project ORDER BY project_id ASC")
            existing_ids = cursor.fetchall()

            # Find the smallest missing project_id
            next_project_id = 1
            for project_id in existing_ids:
                if project_id[0] != next_project_id:
                    break
                next_project_id += 1

            # Insert the new project with the calculated project_id
            query = """
                INSERT INTO project (project_id, project_name, project_description)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (next_project_id, project_name, project_description))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Project '{project_name}' added successfully with ID {next_project_id}.", "success")
            return redirect(url_for('add_project'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_project'))  # Redirect after error

    # Show all data from the project table
    project_data = get_project_data()

    return render_template('add_project.html', project_data=project_data)


@app.route('/add_result_type', methods=['GET', 'POST'])
def add_result_type():
    if request.method == 'POST':
        result_type = request.form.get('result_type')

        if not all([result_type]):
            flash('All fields are required!', 'danger')
            return redirect(url_for('add_result_type'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()
            query = """
                INSERT INTO result_type (result_type)
                VALUES (%s)
            """
            cursor.execute(query, (result_type,))
            db_connection.commit()
            cursor.close()
            db_connection.close()

            flash(f"Result Type '{result_type}' added successfully.", "success")
            return redirect(url_for('add_result_type'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_result_type'))  # Redirect after error

    # Show all data from the result type table
    result_type_data = get_result_type_data()

    return render_template('add_result_type.html', result_type_data=result_type_data)

@app.route('/add_source', methods=['GET', 'POST'])
def add_source():
    if request.method == 'POST':
        source_name = request.form.get('source_name')
        source_description = request.form.get('source_description')

        if not all([source_name, source_description]):
            flash('All fields are required!', 'danger')
            return redirect(url_for('add_source'))  # Redirect to avoid resubmitting the form

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all existing source_id values
            cursor.execute("SELECT source_id FROM source ORDER BY source_id ASC")
            existing_ids = cursor.fetchall()

            # Find the smallest missing source_id
            next_source_id = 1
            for source_id in existing_ids:
                if source_id[0] != next_source_id:
                    break
                next_source_id += 1

            # Insert the new source with the calculated source_id
            query = """
                INSERT INTO source (source_id, source_name, source_description)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (next_source_id, source_name, source_description))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Source '{source_name}' with ID {next_source_id} added successfully.", "success")
            return redirect(url_for('add_source'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_source'))  # Redirect after error

    # Show all data from the source table
    source_data = get_source_data()

    return render_template('add_source.html', source_data=source_data)

@app.route('/add_storage', methods=['GET', 'POST'])
def add_storage():
    if request.method == 'POST':
        storage_name = request.form.get('storage_name')
        
        if not storage_name:
            flash('Storage name is required!', 'danger')
            return redirect(url_for('add_storage'))  # Redirect to avoid resubmitting the form
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all existing storage_id values
            cursor.execute("SELECT storage_id FROM storage ORDER BY storage_id ASC")
            existing_ids = cursor.fetchall()

            # Find the smallest missing storage_id
            next_storage_id = 1
            for storage_id in existing_ids:
                if storage_id[0] != next_storage_id:
                    break
                next_storage_id += 1

            # Insert the new storage with the calculated storage_id
            query = """
                INSERT INTO storage (storage_id, storage_name)
                VALUES (%s, %s)
            """
            cursor.execute(query, (next_storage_id, storage_name))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Storage '{storage_name}' with ID {next_storage_id} added successfully.", "success")
            return redirect(url_for('add_storage'))  # Redirect after successful addition

        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
            return redirect(url_for('add_storage'))  # Redirect after error

    # Show all data from the storage table
    storage_data = get_storage_data()

    return render_template('add_storage.html', storage_data=storage_data)


@app.route('/add_target', methods=['GET', 'POST'])
def add_target():
    if request.method == 'POST':
        target_name = request.form.get('target_name')
        target_type = request.form.get('target_type')
        
        if not all([target_name, target_type]):
            flash('All fields are required!', 'error')
            return redirect(url_for('add_target'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Get all existing target_id values
            cursor.execute("SELECT target_id FROM target ORDER BY target_id ASC")
            existing_ids = cursor.fetchall()

            # Find the smallest missing target_id
            next_target_id = 1
            for target_id in existing_ids:
                if target_id[0] != next_target_id:
                    break
                next_target_id += 1

            # Insert the new target with the calculated target_id
            query = """
                INSERT INTO target (target_id, target_name, target_type)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (next_target_id, target_name, target_type))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Target '{target_name}' with ID {next_target_id} added successfully!", 'success')
            return redirect(url_for('add_target'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('add_target'))
        
    # Show all data from the target table
    target_data = get_target_data()

    return render_template('add_target.html', target_data=target_data)

#Edit values
@app.route('/edit_assay', methods=['GET', 'POST'])
def edit_assay():
    if request.method == 'POST':
        assay_id = request.form.get('assay_id')
        assay_name = request.form.get('assay_name')
        assay_lab = request.form.get('assay_lab')
        target_id = request.form.get('target_id')

        # Check if all fields are filled
        if not all([assay_id, assay_name, assay_lab, target_id]):
            flash('All fields are required!', 'error')
            return redirect(url_for('edit_assay'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the assay exists
            cursor.execute("SELECT * FROM assay WHERE assay_id = %s", (assay_id,))
            assay = cursor.fetchone()

            if not assay:
                flash(f"Assay with ID {assay_id} not found!", 'error')
                return redirect(url_for('edit_assay'))

            # Update the assay details in the database
            query = """
                UPDATE assay
                SET assay_name = %s, assay_lab = %s, target_id = %s
                WHERE assay_id = %s
            """
            cursor.execute(query, (assay_name, assay_lab, target_id, assay_id))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Assay with ID {assay_id} edited successfully!", 'success')
            return redirect(url_for('edit_assay'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('edit_assay'))

    assay_data = get_assay_data()
    target_data = get_target_data() 

    return render_template('edit_assay.html', assay_data=assay_data, target_data=target_data)

@app.route('/edit_chemist', methods=['GET', 'POST'])
def edit_chemist():
    if request.method == 'POST':
        chemist_id = request.form.get('chemist_id')
        chemist_name = request.form.get('chemist_name')
        chemist_description = request.form.get('chemist_description')

        # Check if all fields are filled
        if not all([chemist_id, chemist_name, chemist_description]):
            flash('All fields are required!', 'error')
            return redirect(url_for('edit_chemist'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the chemist exists
            cursor.execute("SELECT * FROM chemist WHERE chemist_id = %s", (chemist_id,))
            chemist = cursor.fetchone()

            if not chemist:
                flash(f"Chemist with ID {chemist_id} not found!", 'error')
                return redirect(url_for('edit_chemist'))

            # Update the chemist details in the database
            query = """
                UPDATE chemist
                SET chemist_name = %s, chemist_description = %s
                WHERE chemist_id = %s
            """
            cursor.execute(query, (chemist_name, chemist_description, chemist_id))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f'Chemist with ID {chemist_id} has been edited successfully!', 'success')
            return redirect(url_for('edit_chemist'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('edit_chemist'))

    chemist_data = get_chemist_data() 

    return render_template('edit_chemist.html', chemist_data=chemist_data)

@app.route('/edit_counterion', methods=['GET', 'POST'])
def edit_counterion():
    if request.method == 'POST':
        ci_code = request.form.get('ci_code')
        ci_smiles = request.form.get('ci_smiles')

        # Check if all fields are filled
        if not all([ci_code, ci_smiles]):
            flash('All fields are required!', 'error')
            return redirect(url_for('edit_counterion'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the counterion exists
            cursor.execute("SELECT * FROM counterion WHERE ci_code = %s", (ci_code,))
            counterion = cursor.fetchone()

            if not counterion:
                flash(f"Counterion with ID {ci_code} not found!", 'error')
                return redirect(url_for('edit_counterion'))

            # Update the counterion details in the database (Only update ci_smiles)
            query = """
                UPDATE counterion
                SET ci_smiles = %s
                WHERE ci_code = %s
            """
            cursor.execute(query, (ci_smiles, ci_code))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f'Counterion with ID {ci_code} has been edited successfully!', 'success')
            return redirect(url_for('edit_counterion'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('edit_counterion'))

    counterion_data = get_counterion_data() 

    return render_template('edit_counterion.html', counterion_data=counterion_data)

@app.route('/edit_project', methods=['GET', 'POST'])
def edit_project():
    if request.method == 'POST':
        project_id = request.form.get('project_id')
        project_name = request.form.get('project_name')
        project_description = request.form.get('project_description')

        # Check if all fields are filled
        if not all([project_id, project_name, project_description]):
            flash('All fields are required!', 'error')
            return redirect(url_for('edit_project'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the project exists
            cursor.execute("SELECT * FROM project WHERE project_id = %s", (project_id,))
            project = cursor.fetchone()

            if not project:
                flash(f"Project with ID {project_id} not found!", 'error')
                return redirect(url_for('edit_project'))

            # Update the project details in the database
            query = """
                UPDATE project
                SET project_name = %s, project_description = %s
                WHERE project_id = %s
            """
            cursor.execute(query, (project_name, project_description, project_id))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f'Project with ID {project_id} has been edited successfully!', 'success')
            return redirect(url_for('edit_project'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('edit_project'))

    project_data = get_project_data()

    return render_template('edit_project.html', project_data=project_data)


@app.route('/edit_result_type', methods=['GET', 'POST'])
def edit_result_type():
    if request.method == 'POST':
        result_type = request.form.get('result_type')
        updated_result_type = request.form.get('updated_result_type')

        # Check if all fields are filled
        if not all([result_type, updated_result_type]):
            flash('Both "Result Type" and "Updated Result Type" fields are required!', 'error')
            return redirect(url_for('edit_result_type'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the original result_type exists
            cursor.execute("SELECT * FROM result_type WHERE result_type = %s", (result_type,))
            existing_result_type = cursor.fetchone()

            if not existing_result_type:
                flash(f'Result type "{result_type}" not found!', 'error')
                return redirect(url_for('edit_result_type'))

            # Update the result_type with the new value
            query = """
                UPDATE result_type
                SET result_type = %s
                WHERE result_type = %s
            """
            cursor.execute(query, (updated_result_type, result_type))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f'Result type "{result_type}" has been updated to "{updated_result_type}" successfully!', 'success')
            return redirect(url_for('edit_result_type'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", 'error')
            return redirect(url_for('edit_result_type'))

    result_type_data = get_result_type_data()

    return render_template('edit_result_type.html', result_type_data=result_type_data)



@app.route('/edit_source', methods=['GET', 'POST'])
def edit_source():
    if request.method == 'POST':
        source_id = request.form.get('source_id')
        source_name = request.form.get('source_name')
        source_description = request.form.get('source_description')

        # Check if all fields are filled
        if not all([source_id, source_name, source_description]):
            flash("All fields are required!", "error")
            return redirect(url_for('edit_source'))
        
        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the source exists
            cursor.execute("SELECT * FROM source WHERE source_id = %s", (source_id,))
            source = cursor.fetchone()

            if not source:
                flash(f"Source with ID {source_id} not found!", "error")
                return redirect(url_for('edit_source'))

            # Update the source details in the database
            query = """
                UPDATE source
                SET source_name = %s, source_description = %s
                WHERE source_id = %s
            """
            cursor.execute(query, (source_name, source_description, source_id))
            db_connection.commit()

            cursor.close()
            db_connection.close()

            flash(f"Source with ID {source_id} updated successfully!", "success")
            return redirect(url_for('edit_source'))
        except mysql.connector.Error as err:
            flash(f"Database error: {err}", "error")
            return redirect(url_for('edit_source'))

    source_data = get_source_data()

    return render_template('edit_source.html', source_data=source_data)


@app.route('/edit_storage', methods=['GET', 'POST'])
def edit_storage():
    if request.method == 'POST':
        storage_id = request.form.get('storage_id')
        storage_name = request.form.get('storage_name')

        # Check if all fields are filled
        if not all([storage_id, storage_name]):
            flash("All fields are required!", "error")
            return redirect(url_for('edit_storage'))

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the storage exists
            cursor.execute("SELECT * FROM storage WHERE storage_id = %s", (storage_id,))
            storage = cursor.fetchone()

            if not storage:
                flash(f"Storage with ID {storage_id} not found!", "error")
                return redirect(url_for('edit_storage'))

            # Update the storage details in the database
            query = """
                UPDATE storage
                SET storage_name = %s
                WHERE storage_id = %s
            """
            cursor.execute(query, (storage_name, storage_id))
            db_connection.commit()

            flash(f"Storage with ID {storage_id} updated successfully!", "success")
        except mysql.connector.Error as err:
            flash(f"Database error: {err}", "error")
        finally:
            cursor.close()
            db_connection.close()

        return redirect(url_for('edit_storage'))

    storage_data = get_storage_data()

    return render_template('edit_storage.html', storage_data=storage_data)


@app.route('/edit_target', methods=['GET', 'POST'])
def edit_target():
    if request.method == 'POST':
        target_id = request.form.get('target_id')
        target_name = request.form.get('target_name')
        target_type = request.form.get('target_type')

        # Check if all fields are filled
        if not all([target_id, target_name, target_type]):
            flash("All fields are required!", "error")
            return redirect(url_for('edit_target'))

        try:
            db_connection = get_db_connection()
            cursor = db_connection.cursor()

            # Check if the target exists
            cursor.execute("SELECT * FROM target WHERE target_id = %s", (target_id,))
            target = cursor.fetchone()

            if not target:
                flash(f"Target with ID {target_id} not found!", "error")
                return redirect(url_for('edit_target'))

            # Update the target details in the database
            query = """
                UPDATE target
                SET target_name = %s, target_type = %s
                WHERE target_id = %s
            """
            cursor.execute(query, (target_name, target_type, target_id))
            db_connection.commit()

            flash(f"Target with ID {target_id} updated successfully!", "success")
        except mysql.connector.Error as err:
            flash(f"Database error: {err}", "error")
        finally:
            cursor.close()
            db_connection.close()

        return redirect(url_for('edit_target'))

    target_data = get_target_data()

    return render_template('edit_target.html', target_data=target_data)



@app.route('/delete_assay', methods=['GET', 'POST'])
def delete_assay():
    # Initialize variable for selected assay
    selected_assay = None

    # If the user submitted the form to select an assay
    if request.method == 'POST':
        assay_id = request.form.get('assay_id')

        # If no assay is selected, show an error
        if not assay_id:
            flash('Please select an assay to delete!', 'danger')
            return redirect(url_for('delete_assay'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the assay based on assay_id
                query = "DELETE FROM assay WHERE assay_id = %s"
                cursor.execute(query, (assay_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"Assay with ID {assay_id} has been deleted.", "success")
                return redirect(url_for('delete_assay'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_assay'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all assay data
            assay_data = get_assay_data()

            # Find selected assay details
            for row in assay_data:
                if row['assay_id'] == assay_id:
                    selected_assay = row
                    break

            # Pass the selected assay to the template for confirmation
            return render_template('delete_assay.html', assay_data=assay_data, selected_assay=selected_assay)

    # If not POST, show the initial page with all assays
    assay_data = get_assay_data()
    return render_template('delete_assay.html', assay_data=assay_data)



@app.route('/delete_chemist', methods=['GET', 'POST'])
def delete_chemist():
    # Initialize variable for selected chemist
    selected_chemist = None

    # If the user submitted the form to select an chemist
    if request.method == 'POST':
        chemist_id = request.form.get('chemist_id')

        # If no chemist is selected, show an error
        if not chemist_id:
            flash('Please select an chemist to delete!', 'danger')
            return redirect(url_for('delete_chemist'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the chemist based on chemist_id
                query = "DELETE FROM chemist WHERE chemist_id = %s"
                cursor.execute(query, (chemist_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"chemist with ID {chemist_id} has been deleted.", "success")
                return redirect(url_for('delete_chemist'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_chemist'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all chemist data
            chemist_data = get_chemist_data()

            # Find selected chemist details
            for row in chemist_data:
                if row['chemist_id'] == chemist_id:
                    selected_chemist = row
                    break

            # Pass the selected chemist to the template for confirmation
            return render_template('delete_chemist.html', chemist_data=chemist_data, selected_chemist=selected_chemist)

    # If not POST, show the initial page with all chemists
    chemist_data = get_chemist_data()
    return render_template('delete_chemist.html', chemist_data=chemist_data)

 
@app.route('/delete_counterion', methods=['GET', 'POST'])
def delete_counterion():
    # Initialize variable for selected counterion
    selected_counterion = None

    # If the user submitted the form to select an counterion
    if request.method == 'POST':
        ci_code = request.form.get('ci_code')

        # If no counterion is selected, show an error
        if not ci_code:
            flash('Please select an counterion to delete!', 'danger')
            return redirect(url_for('delete_counterion'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the counterion based on ci_code
                query = "DELETE FROM counterion WHERE ci_code = %s"
                cursor.execute(query, (ci_code,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"Counterion with ID {ci_code} has been deleted.", "success")
                return redirect(url_for('delete_counterion'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_counterion'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all counterion data
            counterion_data = get_counterion_data()

            # Find selected counterion details
            for row in counterion_data:
                if row['ci_code'] == ci_code:
                    selected_counterion = row
                    break

            # Pass the selected counterion to the template for confirmation
            return render_template('delete_counterion.html', counterion_data=counterion_data, selected_counterion=selected_counterion)

    # If not POST, show the initial page with all counterions
    counterion_data = get_counterion_data()
    return render_template('delete_counterion.html', counterion_data=counterion_data)

@app.route('/delete_project', methods=['GET', 'POST'])
def delete_project():
    # Initialize variable for selected project
    selected_project = None

    # If the user submitted the form to select an project
    if request.method == 'POST':
        project_id = request.form.get('project_id')

        # If no project is selected, show an error
        if not project_id:
            flash('Please select a project to delete!', 'danger')
            return redirect(url_for('delete_project'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the project based on project_id
                query = "DELETE FROM project WHERE project_id = %s"
                cursor.execute(query, (project_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"project with ID {project_id} has been deleted.", "success")
                return redirect(url_for('delete_project'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_project'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all project data
            project_data = get_project_data()

            # Find selected project details
            for row in project_data:
                if row['project_id'] == project_id:
                    selected_project = row
                    break

            # Pass the selected project to the template for confirmation
            return render_template('delete_project.html', project_data=project_data, selected_project=selected_project)

    # If not POST, show the initial page with all projects
    project_data = get_project_data()
    return render_template('delete_project.html', project_data=project_data)

@app.route('/delete_result_type', methods=['GET', 'POST'])
def delete_result_type():
    # Initialize variable for selected result_type
    selected_result_type = None

    # If the user submitted the form to select an result_type
    if request.method == 'POST':
        result_type = request.form.get('result_type')

        # If no result_type is selected, show an error
        if not result_type:
            flash('Please select a result type to delete!', 'danger')
            return redirect(url_for('delete_result_type'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the result_type based on ci_code
                query = "DELETE FROM result_type WHERE result_type = %s"
                cursor.execute(query, (result_type,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"Result Type {result_type} has been deleted.", "success")
                return redirect(url_for('delete_result_type'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_result_type'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all result_type data
            result_type_data = get_result_type_data()

            # Find selected result_type details
            for row in result_type_data:
                if row['result_type'] == result_type:
                    selected_result_type = row
                    break

            # Pass the selected result_type to the template for confirmation
            return render_template('delete_result_type.html', result_type_data=result_type_data, selected_result_type=selected_result_type)

    # If not POST, show the initial page with all result_types
    result_type_data = get_result_type_data()
    return render_template('delete_result_type.html', result_type_data=result_type_data)

@app.route('/delete_source', methods=['GET', 'POST'])
def delete_source():
    # Initialize variable for selected source
    selected_source = None

    # If the user submitted the form to select an source
    if request.method == 'POST':
        source_id = request.form.get('source_id')

        # If no source is selected, show an error
        if not source_id:
            flash('Please select a source to delete!', 'danger')
            return redirect(url_for('delete_source'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the source based on source_id
                query = "DELETE FROM source WHERE source_id = %s"
                cursor.execute(query, (source_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"source with ID {source_id} has been deleted.", "success")
                return redirect(url_for('delete_source'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_source'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all source data
            source_data = get_source_data()

            # Find selected source details
            for row in source_data:
                if row['source_id'] == source_id:
                    selected_source = row
                    break

            # Pass the selected source to the template for confirmation
            return render_template('delete_source.html', source_data=source_data, selected_source=selected_source)

    # If not POST, show the initial page with all sources
    source_data = get_source_data()
    return render_template('delete_source.html', source_data=source_data)

@app.route('/delete_storage', methods=['GET', 'POST'])
def delete_storage():
    # Initialize variable for selected storage
    selected_storage = None

    # If the user submitted the form to select an storage
    if request.method == 'POST':
        storage_id = request.form.get('storage_id')

        # If no storage is selected, show an error
        if not storage_id:
            flash('Please select an storage to delete!', 'danger')
            return redirect(url_for('delete_storage'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the storage based on storage_id
                query = "DELETE FROM storage WHERE storage_id = %s"
                cursor.execute(query, (storage_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"storage with ID {storage_id} has been deleted.", "success")
                return redirect(url_for('delete_storage'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_storage'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all storage data
            storage_data = get_storage_data()

            # Find selected storage details
            for row in storage_data:
                if row['storage_id'] == storage_id:
                    selected_storage = row
                    break

            # Pass the selected storage to the template for confirmation
            return render_template('delete_storage.html', storage_data=storage_data, selected_storage=selected_storage)

    # If not POST, show the initial page with all storages
    storage_data = get_storage_data()
    return render_template('delete_storage.html', storage_data=storage_data)

@app.route('/delete_target', methods=['GET', 'POST'])
def delete_target():
    # Initialize variable for selected target
    selected_target = None

    # If the user submitted the form to select an target
    if request.method == 'POST':
        target_id = request.form.get('target_id')

        # If no target is selected, show an error
        if not target_id:
            flash('Please select an target to delete!', 'danger')
            return redirect(url_for('delete_target'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the target based on target_id
                query = "DELETE FROM target WHERE target_id = %s"
                cursor.execute(query, (target_id,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"target with ID {target_id} has been deleted.", "success")
                return redirect(url_for('delete_target'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_target'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all target data
            target_data = get_target_data()

            # Find selected target details
            for row in target_data:
                if row['target_id'] == target_id:
                    selected_target = row
                    break

            # Pass the selected target to the template for confirmation
            return render_template('delete_target.html', target_data=target_data, selected_target=selected_target)

    # If not POST, show the initial page with all targets
    target_data = get_target_data()
    return render_template('delete_target.html', target_data=target_data)

#Import data



@app.route('/import_lot', methods=['GET', 'POST'])
def import_lot():
    today_date = datetime.today().strftime('%Y-%m-%d')  # Get today's date in YYYY-MM-DD format
    if request.method == 'POST':
        file = request.files.get('csv_file')

        if file and allowed_file(file.filename):
            # Save the uploaded file
            filename = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
            file.save(filename)

            try:
                # Read the CSV file into a pandas DataFrame
                df = pd.read_csv(filename)

                # Check if the required columns exist
                required_columns = ['lot_id', 'received_smiles', 'stoichiometry', 'alt_name']
                if not all(col in df.columns for col in required_columns):
                    flash("The CSV file is missing required columns!", 'danger')
                    return redirect(url_for('import_lot'))

                # Function to generate canonical SMILES
                def generate_canonical(smiles):
                    mol = Chem.MolFromSmiles(smiles)
                    if mol:
                        try:
                            return Chem.MolToSmiles(mol, isomericSmiles=True)
                        except:
                            return None
                    return None

                # Function to extract counterion from SMILES
                def extract_counterion(smiles):
                    if '.' in smiles:
                        molecule_smiles, counterion_smiles = smiles.split('.')
                        return molecule_smiles, counterion_smiles
                    return smiles, None

                # Function to get ci_code from counterion SMILES
                def get_counterion_code(counterion_smiles):
                    if counterion_smiles:
                        db_connection = get_db_connection()
                        cursor = db_connection.cursor()
                        query = "SELECT ci_code FROM counterion WHERE ci_smiles = %s"
                        cursor.execute(query, (counterion_smiles,))
                        result = cursor.fetchone()
                        cursor.close()
                        db_connection.close()
                        if result:
                            return result[0]  # Return ci_code
                    return 0

                # Function to generate random parent_id
                def generate_parent_id():
                    return 'MU' + ''.join(random.choices(string.digits, k=5))

                # Process the data and save to the database
                for _, row in df.iterrows():
                    try:
                        # Prepare the data for insertion
                        lot_id = row['lot_id']
                        alt_name = row['alt_name'] if pd.notna(row['alt_name']) and row['alt_name'] != '' else None

                        stoichiometry = row['stoichiometry']
                        purity = row.get('purity')
                        received_smiles = row['received_smiles']
                        source_id = request.form.get('source_id')
                        project_id = request.form.get('project_id')
                        chemist_id = request.form.get('chemist_id')
                        reg_date = request.form.get('reg_date')

                        # Step 1: Extract counterion and molecule part
                        molecule_smiles, counterion_smiles = extract_counterion(received_smiles)

                        # Step 2: Get counterion ci_code
                        ci_code = get_counterion_code(counterion_smiles)

                        # Step 3: Generate canonical SMILES
                        canonical_smiles = generate_canonical(molecule_smiles)
                        # Step 4–6: Check for existing parent_id and insert data
                        db_connection = get_db_connection()
                        cursor = db_connection.cursor()
                        try:
                            # Step 4: Check if canonical SMILES already has a parent_id
                            query = "SELECT parent_id FROM lot WHERE smiles = %s"
                            cursor.execute(query, (canonical_smiles,))
                            existing_parent_id = cursor.fetchone()

                            # Clear any unread result sets (avoids "Unread result found" error)
                            while cursor.nextset():
                                pass

                            if existing_parent_id:
                                parent_id = existing_parent_id[0]
                            else:
                                parent_id = generate_parent_id()

                            # Step 5: Generate salt_id
                            salt_id = f"{parent_id}-{ci_code}"

                            # Step 6: Insert the data
                            query = """
                                INSERT INTO lot (lot_id, source_id, smiles, stoichiometry, purity, project_id, chemist_id, reg_date, alt_name, parent_id, salt_id, ci_code)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                            """
                            cursor.execute(query, (
                                lot_id, source_id, canonical_smiles, stoichiometry, purity,
                                project_id, chemist_id, reg_date, alt_name, parent_id, salt_id, ci_code
                            ))

                            # Clear again to avoid the same error from INSERT
                            while cursor.nextset():
                                pass

                            db_connection.commit()
                        finally:
                            cursor.close()
                            db_connection.close()

                        
                    except Exception as e:
                        flash(f"Error processing lot ID {lot_id}: {e}", 'danger')
                        continue  # Skip to the next row

                flash("CSV data imported successfully!", 'success')
                return redirect(url_for('import_lot'))
            except Exception as e:
                flash(f"Error processing CSV file: {e}", 'danger')
                return redirect(url_for('import_lot'))
        else:
            flash("Invalid file type! Only CSV files are allowed.", 'danger')
            return redirect(url_for('import_lot'))

    source_data = get_source_data()
    chemist_data = get_chemist_data()
    project_data = get_project_data()
    lot_data = get_lot_data()

    return render_template('import_lot.html', project_data=project_data, chemist_data=chemist_data, source_data=source_data, today_date=today_date, lot_data=lot_data)


@app.route('/import_sample', methods=['GET', 'POST'])
def import_sample():
    if request.method == 'POST':
        file = request.files.get('csv_file')
        
        if file and allowed_file(file.filename):
            # Save the uploaded file
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            
            try:
                # Read the CSV file into a pandas DataFrame
                df = pd.read_csv(filename)
                
                # Check if the required columns exist
                required_columns = ['lot_id']
                if not all(col in df.columns for col in required_columns):
                    flash("The CSV file is missing required columns!", 'danger')
                    return redirect(url_for('import_sample'))
                
                # Create the sample_id by appending "-1" to lot_id
                df['sample_id'] = df['lot_id'].astype(str) + '-1'
                
                # Now you can process the data or save it to the database
                for _, row in df.iterrows():
                    sample_id = row['sample_id']
                    lot_id = row['lot_id']
                    storage_id = request.form.get('storage_id')

                    # Insert the data into the database
                    try:
                        db_connection = get_db_connection()
                        cursor = db_connection.cursor()
                        query = """
                            INSERT INTO sample (sample_id, lot_id, storage_id)
                            VALUES (%s, %s, %s)
                        """
                        cursor.execute(query, (sample_id, lot_id, storage_id))
                        db_connection.commit()
                    except Exception as db_error:
                        flash(f"Database error for lot_id {lot_id}: {db_error}", 'danger')
                    finally:
                        cursor.close()
                        db_connection.close()

                flash("CSV data imported successfully!", 'success')
                return redirect(url_for('import_sample'))
            
            except Exception as e:
                flash(f"Error processing CSV: {e}", 'danger')
                return redirect(url_for('import_sample'))
        
        else:
            flash("Invalid file type! Only CSV files are allowed.", 'danger')
            return redirect(url_for('import_sample'))
    
    # Fetch storage data for the dropdown
    storage_data = get_storage_data()
    sample_data = get_sample_data()
    return render_template('import_sample.html', storage_data=storage_data,sample_data=sample_data)



@app.route('/import_activity', methods=['GET', 'POST'])
def import_activity():
    if request.method == 'POST':
        file = request.files['csv_file']
        
        if file and allowed_file(file.filename):
            # Save the uploaded file
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            
            try:
                # Read the CSV file into a pandas DataFrame
                df = pd.read_csv(filename)
                
                # Check if the required columns exist
                required_columns = ['lot_id', 'result_type', 'result_relation', 'result_value']
                if not all(col in df.columns for col in required_columns):
                    flash("The CSV file is missing required columns!", 'danger')
                    return redirect(url_for('import_activity'))
                
                # Assign unique sample_id
                lot_id_counts = {}
                sample_ids = []
                
                for lot_id in df['lot_id']:
                    lot_id_counts[lot_id] = lot_id_counts.get(lot_id, 0) + 1
                    sample_ids.append(f"{lot_id}-{lot_id_counts[lot_id]}")
                
                df['sample_id'] = sample_ids

                # Get the reg_date from the form
                reg_date = request.form.get('reg_date')  # Get registration date from the form

                # Process each row and insert into the database
                for _, row in df.iterrows():
                    try:
                        # Prepare the data for insertion
                        assay_id = request.form.get('assay_id')  # Assume assay_id is chosen in the form
                        result_type = row['result_type']
                        result_relation = row['result_relation']
                        result_value = row['result_value']
                        sample_id = row['sample_id']

                        # Insert the data into the database
                        db_connection = get_db_connection()
                        cursor = db_connection.cursor()
                        query = """
                            INSERT INTO activity (assay_id, sample_id, result_type, result_relation, result_value, reg_date)
                            VALUES (%s, %s, %s, %s, %s, %s)
                        """
                        cursor.execute(query, (assay_id, sample_id, result_type, result_relation, result_value, reg_date))
                        db_connection.commit()
                    except Exception as insert_error:
                        flash(f"Error inserting activity for sample_id {sample_id}: {insert_error}", 'danger')
                    finally:
                        cursor.close()
                        db_connection.close()
                
                flash("CSV data imported successfully!", 'success')
                return redirect(url_for('import_activity'))
            except Exception as e:
                flash(f"Error processing CSV: {e}", 'danger')
                return redirect(url_for('import_activity'))
        else:
            flash("Invalid file type! Only CSV files are allowed.", 'danger')
            return redirect(url_for('import_activity'))
    
    # Fetch assay data for the dropdown
    assay_data = get_assay_data()
    activity_data = get_activity_data()
    return render_template('import_activity.html', assay_data=assay_data, activity_data=activity_data)




if __name__ == '__main__':
    app.run(debug=True)