@app.route('/delete_result_type', methods=['GET', 'POST'])
def delete_result_type():
    # Initialize variable for selected result_type
    selected_result_type = None

    # If the user submitted the form to select an result_type
    if request.method == 'POST':
        result_type = request.form.get('result_type')

        # If no result_type is selected, show an error
        if not result_type:
            flash('Please select a result type to delete!', 'danger')
            return redirect(url_for('delete_result_type'))

        # If the user confirmed the deletion (confirm_delete exists), proceed to delete
        if 'confirm_delete' in request.form:
            try:
                db_connection = get_db_connection()
                cursor = db_connection.cursor()

                # Delete the result_type based on ci_code
                query = "DELETE FROM result_type WHERE result_type = %s"
                cursor.execute(query, (result_type,))
                db_connection.commit()

                cursor.close()
                db_connection.close()

                flash(f"Result Type {result_type} has been deleted.", "success")
                return redirect(url_for('delete_result_type'))  # Redirect after successful deletion

            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")
                return redirect(url_for('delete_result_type'))

        # If it's just the form submission (no confirmation yet), show confirmation step
        else:
            # Fetch all result_type data
            result_type_data = get_result_type_data()

            # Find selected result_type details
            for row in result_type_data:
                if row['result_type'] == result_type:
                    selected_result_type = row
                    break

            # Pass the selected result_type to the template for confirmation
            return render_template('delete_result_type.html', result_type_data=result_type_data, selected_result_type=selected_result_type)

    # If not POST, show the initial page with all result_types
    result_type_data = get_result_type_data()
    return render_template('delete_result_type.html', result_type_data=result_type_data)