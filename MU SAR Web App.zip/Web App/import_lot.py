from datetime import datetime

@app.route('/import_lot', methods=['GET', 'POST'])
def import_lot():
    today_date = datetime.today().strftime('%Y-%m-%d')  # Get today's date in YYYY-MM-DD format
    if request.method == 'POST':
        file = request.files['csv_file']
        
        if file and allowed_file(file.filename):
            # Save the uploaded file
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            
            try:
                # Read the CSV file into a pandas DataFrame
                df = pd.read_csv(filename)
                
                # Check if the required columns exist
                required_columns = ['lot_id', 'received_smiles', 'stoichiometry', 'alt_name']
                if not all(col in df.columns for col in required_columns):
                    flash("The CSV file is missing required columns!", 'danger')
                    return redirect(url_for('import_lot'))
                
                # Function to generate canonical SMILES
                def generate_canonical(smiles):
                    mol = Chem.MolFromSmiles(smiles)
                    if mol is not None:
                        try:
                            canonical_smiles = Chem.MolToSmiles(mol, isomericSmiles=True)
                            return canonical_smiles
                        except:
                            return None
                    else:
                        return None
                
                # Apply the canonical SMILES generation to the 'received_smiles' column
                df['smiles'] = df['received_smiles'].apply(generate_canonical)
                
                # Now you can process the data or save it to the database, if necessary
                for _, row in df.iterrows():
                    # Prepare the data for insertion
                    lot_id = row['lot_id']
                    alt_name = row['alt_name']
                    stoichiometry = row['stoichiometry']
                    purity = row['purity']
                    smiles = row['smiles']
                    source_id = request.form.get('source_id')
                    project_id = request.form.get('project_id')
                    chemist_id = request.form.get('chemist_id')
                    reg_date = request.form.get('reg_date')

                    # Insert the data into the database (modify the query as needed)
                    db_connection = get_db_connection()
                    cursor = db_connection.cursor()
                    query = """
                        INSERT INTO lot (lot_id, source_id, smiles, stoichiometry, purity, project_id, chemist_id, reg_date, alt_name)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(query, (lot_id, source_id, smiles, stoichiometry, purity, project_id, chemist_id, reg_date, alt_name))
                    db_connection.commit()
                    cursor.close()
                    db_connection.close()
                
                flash("CSV data imported successfully!", 'success')
                return redirect(url_for('import_lot'))
            except Exception as e:
                flash(f"Error processing CSV: {e}", 'danger')
                return redirect(url_for('import_lot'))
        
        else:
            flash("Invalid file type! Only CSV files are allowed.", 'danger')
            return redirect(url_for('import_lot'))
    
    # Fetch assay data for the dropdown and pass the current date
    assay_data = get_assay_data()
    return render_template('import_lot.html', assay_data=assay_data, today_date=today_date)
