import os
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem

data = data.drop_duplicates()

# Function to generate canonical SMILES
def generate_canonical(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        try:
            canonical_smiles = Chem.MolToSmiles(mol, isomericSmiles=True)
            return canonical_smiles
        except:
            return None
    else:
        return None

# Generate canonical SMILES
canonical_smiles = []
for smiles in data:
    canonical = generate_canonical(smiles)
    if canonical:
        canonical_smiles.append(canonical)
    else:
        canonical_smiles.append("")

# Create a DataFrame for the combined dataset
all_smiles_df = pd.DataFrame({'SMILES_NOT_CANONICAL': combined_smiles, 'SMILES_CANONICAL': canonical_smiles})

# Path to save the combined dataset
output_file = "ALL_SMILES_1.xlsx"

# Write the combined dataset to an Excel file
all_smiles_df.to_excel(output_file, index=False)

print(f"Combined dataset saved to: {output_file}")